package com.twbh.common.dto;

public class WeatherVO {
	private int loc_x;
	private int loc_y;
	
	public int getLoc_x() {
		return loc_x;
	}
	public void setLoc_x(int loc_x) {
		this.loc_x = loc_x;
	}
	public int getLoc_y() {
		return loc_y;
	}
	public void setLoc_y(int loc_y) {
		this.loc_y = loc_y;
	}

	

}
