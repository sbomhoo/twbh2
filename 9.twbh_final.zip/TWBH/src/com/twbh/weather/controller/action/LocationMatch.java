package com.twbh.weather.controller.action;

public class LocationMatch {
	
	public String matchCity(String loc){
		
		if(loc.equals("seoul")){
			loc = "서울특별시";
		}else if(loc.equals("sejong")){
			loc="세종특별자치시";
		}else if(loc.equals("cnamdo")){
			loc="충청남도";
		}else if(loc.equals("dg")){
			loc="대구광역시";
		}else if(loc.equals("ich")){
			loc="인천광역시";
		}else if(loc.equals("cbuckdo")){
			loc="충청북도";
		}else if(loc.equals("kb")){
			loc="경상북도";
		}else if(loc.equals("kw")){
			loc="강원도";
		}else if(loc.equals("jnamdo")){
			loc="전라남도";
		}else if(loc.equals("dj")){
			loc="대전광역시";
		}else if(loc.equals("kkd")){
			loc="경기도";
		}else if(loc.equals("jbuckdo")){
			loc="전라북도";
		}else if(loc.equals("knamdo")){
			loc="경상남도";
		}else if(loc.equals("bs")){
			loc="부산광역시";
		}else if(loc.equals("kj")){
			loc="광주광역시";
		}else if(loc.equals("us")){
			loc="울산광역시";
		}else if(loc.equals("jj")){
			loc="제주특별자치도";
		}
		return loc;
	}

}
